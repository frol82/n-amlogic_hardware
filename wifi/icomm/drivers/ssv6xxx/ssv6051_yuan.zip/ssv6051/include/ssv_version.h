#ifndef _SSV_VERSION_H_
#define _SSV_VERSION_H_

static u32 ssv_root_version = 15962;

#define SSV_ROOT_URl "http://192.168.15.30/svn/software/project/release/android/box/aml_s905/6051.Q0.1009.18.e10108-ty-ap"
#define COMPILERHOST "joy"
#define COMPILERDATE "08-29-2017-12:49:08"
#define COMPILEROS "linux"
#define COMPILEROSARCH "x86_64-linux-gnu-thread-multi"

#endif

