#/bin/bash

killall dhcpd
#ps aux|grep dhcpd
