#ifndef _SSV_VERSION_H_
#define _SSV_VERSION_H_

static u32 ssv_root_version = 15349;

#define SSV_ROOT_URl "http://192.168.15.30/svn/software/project/release/android/box/aml_s905/6051.Q0.1009.18.e10102/ssv6xxx"
#define COMPILERHOST "software-pc"
#define COMPILERDATE "06-06-2017-10:12:34"
#define COMPILEROS "linux"
#define COMPILEROSARCH "x86_64-linux-gnu-thread-multi"

#endif

